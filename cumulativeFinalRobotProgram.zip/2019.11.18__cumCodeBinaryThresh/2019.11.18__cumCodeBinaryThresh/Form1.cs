﻿using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

/// General Notes
/// Name: Dorie Coggin
/// Project: UR2 Term Project (Autonomous Robot Arm)

/// NOTE TO PROFESSOR
/// all additional sources used in the program below will be mentioned
/// in the sources section. Each source is assigned a number which will
/// be referenced in the code to indicate where it is used. Thanks! 
/// 

#region Sources used 

/// Source 1: https://docs.opencv.org/2.4/modules/imgproc/doc/structural_analysis_and_shape_descriptors.html
/// Source 2: http://www.emgu.com/wiki/index.php/Shape_(Triangle,_Rectangle,_Circle,_Line)_Detection_in_CSharp
/// 
/// People used to help with the code/bounce ideas off of
/// Prof Long, Bryce, Joe, Docker, Brad, Sam

#endregion

namespace _2019._11._18__cumCodeBinaryThresh
{
    public partial class Form1 : Form
    {
        #region VideoCapture, Arduino and Thread variable initialization 

        // Create videocapture and thread variables
        VideoCapture _capture;
        Thread _captureThread;

        // Arduino initialization
        SerialPort arduinoSerial = new SerialPort();
        bool enableCoordinateSending = true;
        Thread serialMonitoringThread;

        bool requestAnotherShape = false;
        int startUpVar = 1;     // represents initial boot up of program
        int shapeRetrievalTries = 0;

        #endregion 

        #region General Form Maintenance and Setup 

        public Form1()
        {
            // form setup
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // begin video capture 
            _capture = new VideoCapture(1);     // 1 = webcam, 0 = default laptop cam
            _captureThread = new Thread(processImage);  // call processImage function
            _captureThread.Start();

            // arduino setup for serial communication
            try
            {
                arduinoSerial.PortName = "COM7";
                arduinoSerial.BaudRate = 115200;
                arduinoSerial.Open();
                serialMonitoringThread = new Thread(MonitorSerialData);
                serialMonitoringThread.Start();
                xInput.Text = "130";
                yInput.Text = "224";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Initializing COM port");
                Close(); 
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //terminate the image procession thread to avoid ophaned processes 
            _captureThread.Abort();
            serialMonitoringThread.Abort();
        }

        #endregion    
        
        #region Main Capture Function
        
        /// processImage function does the majority of the work for this program. It 
        /// resizes the frames for the picture box outputs, puts a binary threshold on
        /// the video stream and finds the contours in the grayscale image. It outputs
        /// the num of contours found and displays the output images in the Form. It
        /// also calls the markDetectedObject function
        
        private void processImage()
        {
            while (_capture.IsOpened)
            {
                #region Initial Boot Up

                if (startUpVar == 1)
                {
                    Thread.Sleep(500);
                    // pause the thread so that the camera can calibrate and focus before starting
                    startUpVar = 0;

                    // set requestNewShape bool = true for initial shape search 
                    requestAnotherShape = true;
                }

                #endregion

                #region frame maintenance and resizing 

                // frame maintenance 
                // create mats for the picture boxes
                Mat inputImg = _capture.QueryFrame();

                // resize the images to the picture box aspect ration
                int newHeight = (inputImg.Size.Height * sourcePictureBox.Size.Width) / inputImg.Size.Width;
                Size newSize = new Size(sourcePictureBox.Size.Width, newHeight);
                CvInvoke.Resize(inputImg, inputImg, newSize);       // resize frame
                int frameArea = newHeight * sourcePictureBox.Width;     // used to determine if contours are valid shapes 

                #endregion

                #region Divide picture box into a grid

                // determine width and height of image frame for arduino 
                // calculation. helps find the actual location of the shape
                // on the paper in inches instead of pixels
                // these values represent the pixel values, not inches
                int frameW = gridPictureBox.Size.Width;
                int frameH = gridPictureBox.Size.Height;

                // 

                #endregion  

                #region Binary Thresholding Picture Box

                Mat workingImage = inputImg.Clone();

                // create a copy of the original image 
                var binaryImg = workingImage.ToImage<Gray, byte>().ThresholdBinary(new Gray(125), new Gray(255));

                //create new mats for the thresholding & thresh value
                var decoratedImg = new Mat();   // image to draw on
                var thresholdImg = new Mat();   // black and white image
                int threshVal = 125;    // set threshold value
                int threshMax = 255;    // max threshold value 

                //apply the binary threshold
                CvInvoke.Threshold(binaryImg, thresholdImg, threshVal, threshMax, 0);
                    // input = binaryImg, output = thresholdImg
                    // threshVal and threshMax are the threshold Values
                    // 0 = binary type thresholding at end 

                // copy the thresholded image to decorate / draw on 
                CvInvoke.CvtColor(thresholdImg, decoratedImg, typeof(Gray), typeof(Bgr));

                #endregion

                #region Finding contours in image and output data

                // create a point variable to represent center coordinates of found shape 
                Point targetPoint = new Point();

                // create variable to determine the shape 
                string shape = "triangle";

                // build the list of contours 
                using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                {
                    // find the contours in the thresholded image 
                    CvInvoke.FindContours(thresholdImg, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);

                    // determine the shapes found 
                    for (int i = 0; i < contours.Size; i++)
                    {
                        // create your contour array 
                        VectorOfPoint contour = contours[i];

                        using (VectorOfPoint approxContour = new VectorOfPoint())
                        {
                            // source 1 
                            // source 2

                            // approximate the polygonal curve
                            CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * .05, true);

                            // only consider the contours with an area greater than 250 and less than 1/2 of the frame 
                            if (CvInvoke.ContourArea(approxContour, false) > 250 && CvInvoke.ContourArea(approxContour, false) < frameArea / 2) 
                            {
                                if (approxContour.Size == 3)
                                {
                                    // designates a triangle has been identified 

                                    // draw a green contour around the triangle on the original image 
                                    CvInvoke.Polylines(workingImage, contour, true, new Bgr(Color.Green).MCvScalar, 2);

                                    // set shape 
                                    shape = "triangle";
                                    // end of if contours == 3
                                }
                                
                                else if (approxContour.Size == 4)
                                {
                                    // designates a square has been identified

                                    // draw a red contour around the square on the original image
                                    CvInvoke.Polylines(workingImage, contour, true, new Bgr(Color.Red).MCvScalar, 2);

                                    // set shape 
                                    shape = "square";
                                    // end of if contours == 4
                                }

                                // create a bounding box around the shape in the images 
                                Rectangle boundingBox = CvInvoke.BoundingRectangle(contours[i]);

                                // draw bounding box around the shapes on the binary image
                                CvInvoke.Rectangle(decoratedImg, boundingBox, new Bgr(Color.DeepPink).MCvScalar);

                                // draw the contours on the thresholded image
                                CvInvoke.Polylines(decoratedImg, contour, true, new Bgr(Color.White).MCvScalar, 1);

                                // identify the target point for the center coordinates of the shape
                                targetPoint = new Point(boundingBox.X + boundingBox.Width / 2,
                                    boundingBox.Y + boundingBox.Height / 2);

                                // call the mark detected object function 
                                markDetectedObject(workingImage, contours[i], boundingBox, CvInvoke.ContourArea(contour));

                                // end of if area > 250 satement 
                            }

                            // end of using vector of point statement 
                        }

                        // end of for loop to determine found shapes 
                    }


                    // display the number of contours and coordinates of one shape 
                    Invoke(new Action(() =>
                    {
                        // display data on form
                        numContours.Text = $"There are {contours.Size} contours detected";
                        shapeCoords.Text = $"The location is {targetPoint.X}X and {targetPoint.Y}Y";

                        // output the images into picture boxes
                        sourcePictureBox.Image = inputImg.Bitmap;
                        gridPictureBox.Image = workingImage.Bitmap;
                        contourPictureBox.Image = decoratedImg.Bitmap;

                    }));

                    

                    // end of using vector of vector of point statement 

                }

                
                #region send coordinates to arduino

                if (requestAnotherShape == true)
                {
                    // initialize coordinate variable
                    double x = targetPoint.X;
                    double y = targetPoint.Y;   
                    int z = -1;     // represents the shape seen

                    shapeRetrievalTries++;
                    Invoke(new Action(() =>
                    {
                        // update labels on form 
                        lockStateToolStripStatusLabel.Text = $"Retrieval in Progress";
                        numShapeTries.Text = $"Number of Tries: {shapeRetrievalTries}";

                        // represents the previous coordinates sent to arduino
                        xInput.Text = x.ToString();
                        yInput.Text = y.ToString();

                        // output the frame height and width to form
                        frameHeightLbl.Text = $"Height: {sourcePictureBox.Height}";
                        frameWidthLbl.Text = $"Width: {sourcePictureBox.Width}";
                    }));

                    // send arduino the coordinate information for the shape 
                    if (!enableCoordinateSending)
                    {
                        MessageBox.Show("Temporarily locked...");
                        return;
                    }

                    // determine shape based on the shape string
                    if (shape == "triangle")
                    {
                        z = 1;
                        Invoke(new Action(() =>
                        {
                            determineShapeLbl.Text = "Triangle";
                        }));
                    }
                    else if (shape == "square")
                    {
                        z = 2;
                        Invoke(new Action(() =>
                        {
                            determineShapeLbl.Text = "Square";
                        }));
                    }

                    // change coordinate value if point coordinate == 62 or == 60
                    // we are using the ASCII table to send values here with the < or >
                    // character representing the end/beginning of the data stream.
                    // the value 60 and 62 in ASCII represent < or >, so it will end 
                    // data communication. therefore, we change the values to 61
                    if (x == 60 || x == 62)
                    {
                        x = 61;
                    }
                    else if (y == 60 || y == 62)
                    {
                        y = 61;
                    }

                    byte[] buffer = new byte[5]
                    {
                        Encoding.ASCII.GetBytes("<")[0],
                        Convert.ToByte(x),
                        Convert.ToByte(y),
                        Convert.ToByte(z),
                        Encoding.ASCII.GetBytes(">")[0]
                    };
                    arduinoSerial.Write(buffer, 0, 5);


                    // set requestAnotherShape == false until arduino asks again
                    requestAnotherShape = false;
                    Invoke(new Action(() =>
                    {
                        lockStateToolStripStatusLabel.Text = "Searching for Shapes";
                    }));
                }

                #endregion


                #endregion
                
               
                // end of while capture is opened 
            }

            // end of process image function 
        }

        #endregion

        #region secondary video capture functions 

        /// markDetectedObject determines the center of the found shape, draws a circle on the 
        /// center of the found shape, and calls writeMultilineText function to display the 
        /// shape's area and location on the screen 
        private static void markDetectedObject(Mat frame, VectorOfPoint contour, Rectangle boundingBox, double area)
        {
            // determine the center of the found shape 
            Point center = new Point(boundingBox.X + boundingBox.Width / 2, boundingBox.Y + boundingBox.Height / 2);

            // determine the data to be displayed next to each identified shape 
            var info = new string[]
            {
                $"Area: {area}",
                $"Position: {center.X}, {center.Y}"
            };

            // call write multiline text function to display the info string array
            writeMultilineText(frame, info, new Point(center.X, center.Y - 15));

            // draw the circle on the center of the found shape 
            CvInvoke.Circle(frame, center, 2, new Bgr(Color.White).MCvScalar);

            // end of Mark Detected Object function 
        }

        /// writeMultilineText function displays the input information in the form of 
        /// multiple lines on the designated image or picture box
        private static void writeMultilineText(Mat frame, string[] lines, Point origin)
        {
            // to print text 
            for (int i = 0; i < lines.Length; i++)
            {
                int y = i * 10 + origin.Y;      // move down each line
                CvInvoke.PutText(frame, lines[i], new Point(origin.X, y),
                    FontFace.HersheyPlain, 0.8, new Bgr(Color.White).MCvScalar);

                // end of for loop
            }

            // end of write multiline text function 
        }

        #endregion

        #region secondary Arduino functions 

        private void MonitorSerialData()
        {
            while(true)
            {
                // block until \n character is received, extract command data 
                string msg = arduinoSerial.ReadLine();

                // confirm the string has both < and > characters 
                if (msg.IndexOf("<") == -1 || msg.IndexOf(">") == -1)
                {
                    continue;
                }

                // remove everything before the < character
                msg = msg.Substring(msg.IndexOf("<") + 1);

                // remove everything after the > character 
                msg = msg.Remove(msg.IndexOf(">"));

                // if the resulting string is empty, disregard and move on 
                if (msg.Length == 0)
                {
                    continue;
                }

                // parse the command
                if (msg.Substring(0,1) == "P")
                {
                    // display the point data received by arduino on the form 
                    Invoke(new Action(() =>
                   {
                       returnedPointLbl.Text = $"Returned Point Data: { msg.Substring(1)}";
                   }));

                    // allow arduino to request another shape to move robot
                    requestAnotherShape = true;
                }
            }
        }

        #endregion


        // keep all code above these two brackets 
        // end bracket for class Form1
    }

    // end bracket for namespace _2019._11._18__cumCodeBinaryThresh
}
