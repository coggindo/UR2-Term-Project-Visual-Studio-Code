﻿namespace _2019._11._18__cumCodeBinaryThresh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sourcePictureBox = new System.Windows.Forms.PictureBox();
            this.contourPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numContours = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.shapeCoords = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.gridPictureBox = new System.Windows.Forms.PictureBox();
            this.xInput = new System.Windows.Forms.TextBox();
            this.yInput = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.lockStateToolStripStatusLabel = new System.Windows.Forms.ToolStripLabel();
            this.numShapeTries = new System.Windows.Forms.ToolStripLabel();
            this.returnedPointLbl = new System.Windows.Forms.Label();
            this.angleLbl = new System.Windows.Forms.Label();
            this.determineShapeLbl = new System.Windows.Forms.Label();
            this.frameWidthLbl = new System.Windows.Forms.Label();
            this.frameHeightLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contourPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPictureBox)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sourcePictureBox
            // 
            this.sourcePictureBox.Location = new System.Drawing.Point(25, 24);
            this.sourcePictureBox.Name = "sourcePictureBox";
            this.sourcePictureBox.Size = new System.Drawing.Size(280, 280);
            this.sourcePictureBox.TabIndex = 1;
            this.sourcePictureBox.TabStop = false;
            // 
            // contourPictureBox
            // 
            this.contourPictureBox.Location = new System.Drawing.Point(350, 24);
            this.contourPictureBox.Name = "contourPictureBox";
            this.contourPictureBox.Size = new System.Drawing.Size(280, 280);
            this.contourPictureBox.TabIndex = 2;
            this.contourPictureBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 325);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Original Image";
            // 
            // numContours
            // 
            this.numContours.AutoSize = true;
            this.numContours.Location = new System.Drawing.Point(104, 362);
            this.numContours.Name = "numContours";
            this.numContours.Size = new System.Drawing.Size(98, 17);
            this.numContours.TabIndex = 9;
            this.numContours.Text = "Num Contours";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(455, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Contour Image";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(104, 427);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Coordinates";
            // 
            // shapeCoords
            // 
            this.shapeCoords.AutoSize = true;
            this.shapeCoords.Location = new System.Drawing.Point(104, 469);
            this.shapeCoords.Name = "shapeCoords";
            this.shapeCoords.Size = new System.Drawing.Size(95, 17);
            this.shapeCoords.TabIndex = 12;
            this.shapeCoords.Text = "Canny coords";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(794, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "Shapes Seen";
            // 
            // gridPictureBox
            // 
            this.gridPictureBox.Location = new System.Drawing.Point(711, 24);
            this.gridPictureBox.Name = "gridPictureBox";
            this.gridPictureBox.Size = new System.Drawing.Size(280, 280);
            this.gridPictureBox.TabIndex = 15;
            this.gridPictureBox.TabStop = false;
            // 
            // xInput
            // 
            this.xInput.Location = new System.Drawing.Point(367, 373);
            this.xInput.Name = "xInput";
            this.xInput.Size = new System.Drawing.Size(100, 22);
            this.xInput.TabIndex = 17;
            // 
            // yInput
            // 
            this.yInput.Location = new System.Drawing.Point(367, 421);
            this.yInput.Name = "yInput";
            this.yInput.Size = new System.Drawing.Size(100, 22);
            this.yInput.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(331, 373);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 17);
            this.label5.TabIndex = 19;
            this.label5.Text = "X:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(331, 421);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 17);
            this.label6.TabIndex = 20;
            this.label6.Text = "Y:";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lockStateToolStripStatusLabel,
            this.numShapeTries});
            this.toolStrip1.Location = new System.Drawing.Point(0, 515);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1192, 25);
            this.toolStrip1.TabIndex = 22;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // lockStateToolStripStatusLabel
            // 
            this.lockStateToolStripStatusLabel.Name = "lockStateToolStripStatusLabel";
            this.lockStateToolStripStatusLabel.Size = new System.Drawing.Size(49, 22);
            this.lockStateToolStripStatusLabel.Text = "Status";
            // 
            // numShapeTries
            // 
            this.numShapeTries.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.numShapeTries.Name = "numShapeTries";
            this.numShapeTries.Size = new System.Drawing.Size(73, 22);
            this.numShapeTries.Text = "Shape Try";
            // 
            // returnedPointLbl
            // 
            this.returnedPointLbl.AutoSize = true;
            this.returnedPointLbl.Location = new System.Drawing.Point(632, 421);
            this.returnedPointLbl.Name = "returnedPointLbl";
            this.returnedPointLbl.Size = new System.Drawing.Size(141, 17);
            this.returnedPointLbl.TabIndex = 23;
            this.returnedPointLbl.Text = "Returned Point Data:";
            // 
            // angleLbl
            // 
            this.angleLbl.AutoSize = true;
            this.angleLbl.Location = new System.Drawing.Point(630, 382);
            this.angleLbl.Name = "angleLbl";
            this.angleLbl.Size = new System.Drawing.Size(117, 17);
            this.angleLbl.TabIndex = 25;
            this.angleLbl.Text = "Angle of Rotation";
            // 
            // determineShapeLbl
            // 
            this.determineShapeLbl.AutoSize = true;
            this.determineShapeLbl.Location = new System.Drawing.Point(632, 459);
            this.determineShapeLbl.Name = "determineShapeLbl";
            this.determineShapeLbl.Size = new System.Drawing.Size(49, 17);
            this.determineShapeLbl.TabIndex = 26;
            this.determineShapeLbl.Text = "Shape";
            // 
            // frameWidthLbl
            // 
            this.frameWidthLbl.AutoSize = true;
            this.frameWidthLbl.Location = new System.Drawing.Point(885, 383);
            this.frameWidthLbl.Name = "frameWidthLbl";
            this.frameWidthLbl.Size = new System.Drawing.Size(84, 17);
            this.frameWidthLbl.TabIndex = 27;
            this.frameWidthLbl.Text = "frame Width";
            // 
            // frameHeightLbl
            // 
            this.frameHeightLbl.AutoSize = true;
            this.frameHeightLbl.Location = new System.Drawing.Point(885, 415);
            this.frameHeightLbl.Name = "frameHeightLbl";
            this.frameHeightLbl.Size = new System.Drawing.Size(89, 17);
            this.frameHeightLbl.TabIndex = 28;
            this.frameHeightLbl.Text = "frame Height";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1192, 540);
            this.Controls.Add(this.frameHeightLbl);
            this.Controls.Add(this.frameWidthLbl);
            this.Controls.Add(this.determineShapeLbl);
            this.Controls.Add(this.angleLbl);
            this.Controls.Add(this.returnedPointLbl);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.yInput);
            this.Controls.Add(this.xInput);
            this.Controls.Add(this.gridPictureBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.shapeCoords);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numContours);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.contourPictureBox);
            this.Controls.Add(this.sourcePictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contourPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPictureBox)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox sourcePictureBox;
        private System.Windows.Forms.PictureBox contourPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label numContours;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label shapeCoords;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox gridPictureBox;
        private System.Windows.Forms.TextBox xInput;
        private System.Windows.Forms.TextBox yInput;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel lockStateToolStripStatusLabel;
        private System.Windows.Forms.Label returnedPointLbl;
        private System.Windows.Forms.Label angleLbl;
        private System.Windows.Forms.ToolStripLabel numShapeTries;
        private System.Windows.Forms.Label determineShapeLbl;
        private System.Windows.Forms.Label frameWidthLbl;
        private System.Windows.Forms.Label frameHeightLbl;
    }
}

